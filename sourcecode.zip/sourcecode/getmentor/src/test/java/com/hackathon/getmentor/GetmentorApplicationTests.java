package com.hackathon.getmentor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetmentorApplicationTests {

	@Test
	void contextLoads() {
	}

}
