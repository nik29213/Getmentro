import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentee',
  templateUrl: './mentee.component.html',
  styleUrls: ['./mentee.component.css']
})
export class MenteeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
