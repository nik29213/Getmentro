
export class Skill {
    id!: number;
    skillName!: string;

}
